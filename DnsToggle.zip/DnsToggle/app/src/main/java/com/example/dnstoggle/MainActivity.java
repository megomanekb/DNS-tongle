package com.example.dnstoggle;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 3, pad, pad);

        Button btn = new Button(this);
        btn.setText(R.string.toggle);
        btn.setOnClickListener(v -> {
            if (!Dns.toggle(this)) {
                Toast.makeText(this, R.string.no_permission, Toast.LENGTH_LONG).show();
            }
            refresh();
        });

        info = new TextView(this);
        info.setTextSize(16);
        info.setTextIsSelectable(true);
        info.setPadding(0, pad, 0, 0);

        root.addView(btn);
        root.addView(info);
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        StringBuilder sb = new StringBuilder();
        sb.append(getString(R.string.mode_fmt, String.valueOf(Dns.getMode(this)))).append("\n");
        if (Dns.hasPermission(this)) {
            sb.append(getString(R.string.perm_ok));
        } else {
            sb.append(getString(R.string.perm_missing)).append("\n\n")
              .append("adb shell pm grant ").append(getPackageName())
              .append(" android.permission.WRITE_SECURE_SETTINGS");
        }
        info.setText(sb.toString());
        DnsWidgetProvider.refreshAll(this);
    }
}
