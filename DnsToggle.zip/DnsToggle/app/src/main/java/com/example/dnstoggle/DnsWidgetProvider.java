package com.example.dnstoggle;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.Toast;

public class DnsWidgetProvider extends AppWidgetProvider {
    static final String ACTION_TOGGLE = "com.example.dnstoggle.TOGGLE";

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) {
            mgr.updateAppWidget(id, build(ctx));
        }
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        if (ACTION_TOGGLE.equals(intent.getAction())) {
            if (!Dns.toggle(ctx)) {
                Toast.makeText(ctx, R.string.no_permission, Toast.LENGTH_LONG).show();
            }
            refreshAll(ctx);
        }
    }

    static void refreshAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, DnsWidgetProvider.class));
        for (int id : ids) {
            mgr.updateAppWidget(id, build(ctx));
        }
    }

    private static RemoteViews build(Context ctx) {
        boolean on = Dns.isOn(ctx);
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget);
        v.setTextViewText(R.id.state, ctx.getString(on ? R.string.on : R.string.off));
        v.setInt(R.id.root, "setBackgroundResource",
                on ? R.drawable.widget_bg_on : R.drawable.widget_bg_off);

        Intent i = new Intent(ctx, DnsWidgetProvider.class).setAction(ACTION_TOGGLE);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.root, pi);
        return v;
    }
}
