package com.example.dnstoggle;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.provider.Settings;

/** Чтение и переключение режима частного DNS (Settings.Global.private_dns_mode). */
final class Dns {
    private static final String KEY_MODE = "private_dns_mode";       // off | opportunistic | hostname
    private static final String KEY_HOST = "private_dns_specifier";  // имя хоста для режима hostname
    private static final String PREFS = "dns_prefs";
    private static final String PREF_LAST_ON = "last_on_mode";

    private Dns() {}

    static boolean hasPermission(Context c) {
        return c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS")
                == PackageManager.PERMISSION_GRANTED;
    }

    static String getMode(Context c) {
        return Settings.Global.getString(c.getContentResolver(), KEY_MODE);
    }

    /** Если значение не задано, Android считает режим "opportunistic", то есть включённым. */
    static boolean isOn(Context c) {
        return !"off".equals(getMode(c));
    }

    /** @return true при успехе, false если нет разрешения WRITE_SECURE_SETTINGS. */
    static boolean toggle(Context c) {
        ContentResolver cr = c.getContentResolver();
        SharedPreferences prefs = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try {
            if (isOn(c)) {
                String cur = getMode(c);
                if (cur != null) {
                    prefs.edit().putString(PREF_LAST_ON, cur).apply();
                }
                Settings.Global.putString(cr, KEY_MODE, "off");
            } else {
                String host = Settings.Global.getString(cr, KEY_HOST);
                boolean hasHost = host != null && !host.isEmpty();
                String mode = prefs.getString(PREF_LAST_ON, null);
                if (mode == null) {
                    mode = hasHost ? "hostname" : "opportunistic";
                }
                if ("hostname".equals(mode) && !hasHost) {
                    mode = "opportunistic";
                }
                Settings.Global.putString(cr, KEY_MODE, mode);
            }
            return true;
        } catch (SecurityException e) {
            return false;
        }
    }
}
